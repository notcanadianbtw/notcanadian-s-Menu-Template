﻿using StupidTemplate.Classes;
using UnityEngine;
using UnityEngine.XR;
using static StupidTemplate.Menu.Main;
using GTPlayer = GorillaLocomotion.Player;

namespace StupidTemplate.Mods
{
    public class Movement
    {
        public static int flySpeedIndex = 2;
        public static float flySpeed = 12f;

        public static void ChangeFlySpeed()
        {
            string[] speedNames = new string[] { "Very Slow", "Slow", "Normal", "Fast", "Very Fast" };
            float[] speedValues = new float[] { 2f, 5f, 12f, 30f, 50f };

            flySpeedIndex++;
            flySpeedIndex %= speedNames.Length;

            GetIndex("Change Fly Speed").overlapText = $"Change Fly Speed [{speedNames[flySpeedIndex]}]";
        }

        public static void Fly()
        {
            if (rightPrimary)
            {
                GTPlayer.Instance.transform.position += GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime * flySpeed;
                GorillaTagger.Instance.bodyCollider.attachedRigidbody.velocity = Vector3.zero;
            }
        }

        public static GameObject platl;
        public static GameObject platr;

        public static void Platforms()
        {
            if (leftGrab)
            {
                if (platl == null)
                {
                    platl = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    platl.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
                    platl.transform.position = GorillaTagger.Instance.leftHandTransform.position;
                    platl.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;

                    FixStickyColliders(platl);

                    ColorChanger colorChanger = platl.AddComponent<ColorChanger>();
                    colorChanger.colors = StupidTemplate.Settings.backgroundColor;
                }
            }
            else
            {
                if (platl != null)
                {
                    GameObject.Destroy(platl);
                    platl = null;
                }
            }

            if (rightGrab)
            {
                if (platr == null)
                {
                    platr = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    platr.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
                    platr.transform.position = GorillaTagger.Instance.rightHandTransform.position;
                    platr.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;

                    FixStickyColliders(platr);

                    ColorChanger colorChanger = platr.AddComponent<ColorChanger>();
                    colorChanger.colors = StupidTemplate.Settings.backgroundColor;
                }
            }
            else
            {
                if (platr != null)
                {
                    GameObject.Destroy(platr);
                    platr = null;
                }
            }
        }

        public static bool previousTeleportTrigger;
        public static void TeleportGun()
        {
            if (rightGrab)
            {
                var GunData = RenderGun();
                GameObject GunPointer = GunData.NewPointer;

                if (rightTrigger && !previousTeleportTrigger)
                {
                    GTPlayer.Instance.transform.position = GunPointer.transform.position + Vector3.up;
                    GorillaTagger.Instance.bodyCollider.attachedRigidbody.velocity = Vector3.zero;
                }

                previousTeleportTrigger = rightTrigger;
            }
        }
    }
}
