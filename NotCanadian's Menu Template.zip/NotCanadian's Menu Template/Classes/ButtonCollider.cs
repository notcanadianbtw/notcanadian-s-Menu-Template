using UnityEngine;
using static StupidTemplate.Menu.Main;

namespace StupidTemplate.Classes
{
	public class Button : MonoBehaviour
	{
		public string relatedText;

		public static float buttonCooldown = 0f;
		
		public void OnTriggerEnter(Collider collider)
		{
			if (Time.time > buttonCooldown && collider == buttonCollider && menu != null)
			{
                buttonCooldown = Time.time + 0.2f;
				Toggle(relatedText);
            }
		}
	}
}
