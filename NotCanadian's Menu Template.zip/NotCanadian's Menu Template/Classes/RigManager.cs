﻿using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using System.Linq;
using UnityEngine;

namespace StupidTemplate.Classes
{
    public class RigManager
    {
        public static VRRig GetVRRigFromPlayer(Player p)
        {
            foreach (VRRig rig in GameObject.FindObjectsOfType<VRRig>())
            {
                if (rig.photonView.Owner == p)
                    return rig;
            }
            return null;
        }

        public static VRRig GetRandomVRRig(bool includeSelf)
        {
            VRRig random = GameObject.FindObjectsOfType<VRRig>()[Random.Range(0, GameObject.FindObjectsOfType<VRRig>().ToArray().Length - 1)];
            if (includeSelf)
            {
                if (!random.isOfflineVRRig)
                    return random;
            }
            else
            {
                if (!random.isOfflineVRRig && !random.photonView.IsMine)
                    return random;
                else
                    return GetRandomVRRig(includeSelf);
            }
            return null;
        }

        public static VRRig GetClosestVRRig()
        {
            float num = float.MaxValue;
            foreach (VRRig vrrig in GameObject.FindObjectsOfType<VRRig>())
            {
                if (!vrrig.isOfflineVRRig && !vrrig.photonView.IsMine)
                {
                    if (Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, vrrig.transform.position) < num)
                    {
                        num = Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, vrrig.transform.position);
                        return vrrig;
                    }
                }
            }
            return null;
        }

        public static PhotonView GetPhotonViewFromVRRig(VRRig p) =>
            p.photonView;

        public static Player GetRandomPlayer(bool includeSelf)
        {
            if (includeSelf)
                return PhotonNetwork.PlayerList[Random.Range(0, PhotonNetwork.PlayerList.Length - 1)];
            else
                return PhotonNetwork.PlayerListOthers[Random.Range(0, PhotonNetwork.PlayerListOthers.Length - 1)];
        }

        public static Player GetPlayerFromVRRig(VRRig p) =>
            GetPhotonViewFromVRRig(p).Owner;

        public static Player GetPlayerFromID(string id)
        {
            foreach (Player target in PhotonNetwork.PlayerList)
            {
                if (target.UserId == id)
                    return target;
            }
            return null;
        }

        public static Color GetPlayerColor(VRRig Player)
        {
            switch (Player.setMatIndex)
            {
                case 1:
                    return Color.red;
                case 2:
                case 11:
                    return new Color32(255, 128, 0, 255);
                case 3:
                case 7:
                    return Color.blue;
                case 12:
                    return Color.green;
                default:
                    return Player.materialsToChangeTo[0].color;
            }
        }
    }
}