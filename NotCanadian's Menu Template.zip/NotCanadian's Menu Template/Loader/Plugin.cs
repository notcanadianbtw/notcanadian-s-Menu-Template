﻿using BepInEx;
using StupidTemplate.Menu;
using StupidTemplate.Managers;

namespace StupidTemplate
{
    [System.ComponentModel.Description(PluginInfo.Description)]
    [BepInPlugin(PluginInfo.GUID, PluginInfo.Name, PluginInfo.Version)]
    public class Plugin : BaseUnityPlugin
    {
        private void Awake()
        {
            gameObject.AddComponent<Main>();
            gameObject.AddComponent<NotificationManager>();
        }
    }
}
