﻿namespace StupidTemplate
{
    public class PluginInfo
    {
        public const string GUID = "org.notcanadian.gorillatag.menutemplate";
        public const string Name = "NotCanadian's Menu Template";
        public const string Description = "Created by @notcanadian with love <3";
        public const string Version = "1.0.0";
    }
}
