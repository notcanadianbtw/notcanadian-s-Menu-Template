﻿using System;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using static StupidTemplate.Settings;

namespace StupidTemplate.Managers
{
    public class NotificationManager : MonoBehaviour // credits to lars for making this, heavily modified by me (notcanadian)
    {
        private void CreateHUD()
        {
            HUDCanvas = new GameObject("Canvas");
            HUDParent = new GameObject("HUD Parent");
            HUDCanvas.AddComponent<Canvas>();
            HUDCanvas.AddComponent<CanvasScaler>();
            HUDCanvas.AddComponent<GraphicRaycaster>();
            HUDCanvas.GetComponent<Canvas>().enabled = true;
            HUDCanvas.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
            HUDCanvas.GetComponent<Canvas>().worldCamera = Camera.main.GetComponent<Camera>();
            HUDCanvas.GetComponent<RectTransform>().sizeDelta = new Vector2(5f, 5f);
            HUDCanvas.GetComponent<RectTransform>().position = new Vector3(Camera.main.transform.position.x, Camera.main.transform.position.y, Camera.main.transform.position.z);
            HUDParent.transform.position = new Vector3(Camera.main.transform.position.x, Camera.main.transform.position.y, Camera.main.transform.position.z - 4.6f);
            HUDCanvas.transform.parent = HUDParent.transform;
            HUDCanvas.GetComponent<RectTransform>().localPosition = new Vector3(0f, 0f, 1.6f);
            Vector3 eulerAngles = HUDCanvas.GetComponent<RectTransform>().rotation.eulerAngles;
            eulerAngles.y = -270f;
            HUDCanvas.transform.localScale = new Vector3(1f, 1f, 1f);
            HUDCanvas.GetComponent<RectTransform>().rotation = Quaternion.Euler(eulerAngles);

            NotificationText = new GameObject("NotificationText")
            {
                transform =
                {
                    parent = HUDCanvas.transform
                }
            }.AddComponent<Text>();
            NotificationText.text = "";
            NotificationText.fontSize = 20;
            NotificationText.font = currentFont;
            NotificationText.rectTransform.sizeDelta = new Vector2(450f, 210f);
            NotificationText.alignment = TextAnchor.LowerLeft;
            NotificationText.rectTransform.localScale = new Vector3(0.00333333333f, 0.00333333333f, 0.33333333f);
            NotificationText.rectTransform.localPosition = new Vector3(-1f, -1f, -0.5f);
            NotificationText.material = new Material(Shader.Find("GUI/Text Shader"));
        }

        private void Update()
        {
            if (!CreatedHUD && Camera.main != null)
            {
                CreateHUD();
                CreatedHUD = true;
            }

            if (!CreatedHUD) return;

            HUDParent.transform.position = new Vector3(Camera.main.transform.position.x, Camera.main.transform.position.y, Camera.main.transform.position.z);
            HUDParent.transform.rotation = Camera.main.transform.rotation;
            if (NotificationText.text != "")
            {
                NotificationDecayTimeCounter++;
                if (NotificationDecayTimeCounter > NotificationDecayTime)
                {
                    Notifilines = null;
                    newtext = "";
                    NotificationDecayTimeCounter = 0;
                    Notifilines = Enumerable.ToArray(Enumerable.Skip(NotificationText.text.Split(Environment.NewLine.ToCharArray()), 1));
                    foreach (string text in Notifilines)
                    {
                        if (text != "")
                            newtext = newtext + text + "\n";
                    }
                    NotificationText.text = newtext;
                }
            }
            else
                NotificationDecayTimeCounter = 0;
        }

        public static void SendNotification(string text)
        {
            try
            {
                if (IsEnabled && PreviousNotifi != text)
                {
                    if (!text.Contains(Environment.NewLine))
                        text += Environment.NewLine;

                    NotificationText.text = NotificationText.text + text;
                    NotificationText.supportRichText = true;
                    PreviousNotifi = text;
                }
            }
            catch
            {
                Debug.LogError("Notification failed, object probably nil due to third person ; " + text);
            }
        }

        public static void ClearAllNotifications() =>
            NotificationText.text = "";

        public static void ClearPastNotifications(int amount)
        {
            string text = "";
            foreach (string text2 in Enumerable.ToArray(Enumerable.Skip(NotificationText.text.Split(Environment.NewLine.ToCharArray()), amount)))
            {
                if (text2 != "")
                    text = text + text2 + "\n";
            }
            NotificationText.text = text;
        }

        private GameObject HUDCanvas;

        private GameObject HUDParent;

        private int NotificationDecayTime = 144;

        private int NotificationDecayTimeCounter;

        public static int NoticationThreshold = 30;

        private string[] Notifilines;

        private string newtext;

        public static string PreviousNotifi;

        private bool CreatedHUD;

        private static Text NotificationText;

        public static bool IsEnabled = true;
    }
}
